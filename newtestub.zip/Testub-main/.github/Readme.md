<p align="center">
    <b>ᴠɪsɪᴛᴏʀs</b><br>
 -->    <img align="middle" src="https://profile-counter.glitch.me/Japanese-X-Userbot/count.svg" />
</p>

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com?color=F70000&lines=ωσяℓ∂+ℓαяgεsт+αη∂+ғαsтεsт+υsεявσт;ηεvεя+εxιsтε∂+ιη+тнιs+ωσяℓ∂.;+𝐉𝐚𝐩𝐚𝐧𝐞𝐬𝐞+𝐗++𝐔𝐬𝐞𝐫𝐛𝐨𝐭+❤️✨+%E2%9D%A4%EF%B8%8F">
  



  
  <img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<h1 align="center">𝐉𝐀𝐏𝐀𝐍𝐄𝐒𝐄-𝐗-𝐔𝐒𝐄𝐑𝐁𝐎𝐓</h1>

![20240201_185316](https://github.com/Japanese-Userbots/Japanese-X-Userbot/assets/156512147/0782c397-c94b-4676-8cf1-89d26257b41a)

<p align="center">
<a href="https://github.com/Team-Japanese/Japanese-X-Userbot/stargazers"><img src="https://img.shields.io/github/stars/Team-Japanese/Japanese-X-Userbot?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/Team-Japanese/Japanese-X-Userbot/network/members"> <img src="https://img.shields.io/github/forks/Team-Japanese/Japanese-X-Userbot?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/Team-Japanese/Japanese-X-Userbot/blob/master/LICENSE"> <img src="https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://github.com/Team-Japanese/Japanese-X-Chatbot"> <img src="https://img.shields.io/github/repo-size/Team-Japanese/Japanese-X-Userbot?color=white&logo=github&logoColor=blue&style=for-the-badge" /></a>
<a href="https://github.com/nobitaaaxd/Team-Japanese/Japanese-X-Userbot/commits/aboutnobitaaxd"> <img src="https://img.shields.io/github/last-commit/Team-Japanese/Japanese-X-Userbot?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
</p>




## 𝑽𝒂𝒓𝒊𝒂𝒃𝒍𝒆𝒔 :

✧ 𝑶𝒘𝒏𝒆𝒓 𝑰𝒅

✧ 𝑶𝒘𝒏𝒆𝒓 𝑵𝒂𝒎𝒆

✧𝑩𝒐𝒕 𝑻𝒐𝒌𝒆𝒏

✧𝑷𝒚𝒓𝒐𝒈𝒓𝒂𝒎 𝐕2 𝑺𝒕𝒓𝒊𝒏𝒈 𝑺𝒆𝒔𝒔𝒊𝒐𝒏



## 𝑫𝒆𝒑𝒍𝒐𝒚 𝑻𝒐 𝑯𝒆𝒓𝒐𝒌𝒖

𝑭𝒐𝒍𝒍𝒐𝒘 𝒕𝒉𝒆𝒔𝒆 𝒔𝒕𝒆𝒑𝒔 𝒕𝒐 𝒅𝒆𝒑𝒍𝒐𝒚 𝑱𝒂𝒑𝒂𝒏𝒆𝒔𝒆-𝑿-𝑼𝒔𝒆𝒓𝒃𝒐𝒕 𝒐𝒏 𝑯𝒆𝒓𝒐𝒌𝒖:

1. **𝑭𝒐𝒓𝒌 & 𝑺𝒕𝒂𝒓 𝒕𝒉𝒊𝒔 𝑹𝒆𝒑𝒐:**
    
2. **𝑯𝒆𝒓𝒐𝒌𝒖 𝑨𝒄𝒄𝒐𝒖𝒏𝒕 𝑳𝒐𝒈𝒊𝒏:**
  

3. **𝑪𝒍𝒊𝒄𝒌 "𝑫𝒆𝒑𝒍𝒐𝒚 𝒕𝒐 𝑯𝒆𝒓𝒐𝒌𝒖":**
   

4. **𝑭𝒊𝒍𝒍 𝑹𝒆𝒒𝒖𝒊𝒓𝒆𝒅 𝑽𝒂𝒓𝒊𝒂𝒃𝒍𝒆𝒔:**
  

<p align="center"><a href="http://dashboard.heroku.com/new?template=https://github.com/Team-Japanese/Japanese-X-Userbot"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-purple?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

## 𝑫𝒆𝒑𝒍𝒐𝒚 𝑻𝒐 𝑹𝒂𝒊𝒍𝒘𝒂𝒚


<p align="center">
    <a href="https://railway.app/new/template?template=https://github.com/Team-Japanese/Japanese-X-Userbot-Deploy"> <img src="https://railway.app/button.svg"/></a>


## 𝑫𝒆𝒑𝒍𝒐𝒚 𝒐𝒏 𝑶𝒌𝒕𝒆𝒕𝒐

  
<p align="center">
    <a href="https://cloud.okteto.com">
    <img src="https://okteto.com/develop-okteto.svg" alt="Deploy on Okteto" width="220px">
    </a>

    
## 𝑫𝒆𝒑𝒍𝒐𝒚 𝑻𝒐 𝑪𝒐𝒅𝒆𝒔𝒑𝒂𝒄𝒆 


</h4>

</p>

<p align="center" >
    <a href="https://github.com/codespaces/new">
    <img src="https://img.shields.io/badge/DEPLOY CODESPACE-h?color=black&style=for-the-badge&logo=visualstudiocode" width="220px" height="38.45" alt="Deploy on CodesSpaces" >
    </a>

## 𝑫𝒆𝒑𝒍𝒐𝒚 𝑻𝒐 𝑲𝒐𝒚𝒆𝒃

<h4 align="center"> Deploy On Koyeb
</h4>

</p>

<p align="center" >
    <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/https://github.com/Team-Japanese/Japanese-X-Userbot&branch=main&build_command=npm%20i&run_command=npm%20start&env[SESSION_ID]&env[OWNER_ID]&env[MONGODB_URI]&&env[OWNER_NAME]&env[PREFIX]=.&env[THUMB_IMAGE]=https://telegra.ph/file/3c341828d86ee7a89c73f.jpg&env[email]=infiniteytff@gmail.com&env[global_url]=instagram.com/sla.sher_&env[FAKE_COUNTRY_CODE]=974&env[READ_MESSAGE]=false&env[DISABLE_PM]=false&env[ANTI_BAD_WORD]=fuck&env[WORKTYPE]=public&env[THEME]=GOJO&env[PACK_INFO]=XLICON;MD&name=xliconuser000&env[KOYEB_NAME]=profilecorruptederror&env[ANTILINK_VALUES]=chat.telegram.com&env[PORT]=8000">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" width="170px" alt="Deploy on Koyeb" >
    </a>




## 𝑫𝒆𝒑𝒍𝒐𝒚 𝒐𝒏 𝑴𝒐𝒈𝒆𝒏𝒊𝒖𝒔

<p align="center">
    <a href="https://studio.mogenius.com/">
    <img src="https://www.cloudflare.com/static/90073b1e5bd8a0765640a20febb3dc22/mogenius_logo_quer.png" alt="Deploy on Mogenius" width="220px">
    </a>

## 𝑫𝒆𝒑𝒍𝒐𝒚 𝒐𝒏 𝑼𝒇𝒇𝒊𝒛𝒛𝒊

<p align="center">
    <a href="https://www.uffizzi.com/">
    <img src="https://i.ibb.co/Y29Kv4X/Screenshot-195.png" alt="Deploy on Uffizzi" width="220px">
    </a>

## 𝑫𝒆𝒑𝒍𝒐𝒚 𝒐𝒏 𝑩𝒐𝒙𝑴𝒊𝒏𝒆𝑾𝒐𝒓𝒍𝒅


<p align="center">
    <a href="https://dash.boxmineworld.com/">
    <img src="https://graph.org/file/2af0e67f320986702ea24.jpg" alt="Deploy on Boxmineworld" width="220px">
    </a>
    <br>
    
# 𝑫𝑰𝑺𝑪𝑳𝑨𝑰𝑴𝑬𝑹


```console
                      ❗️YOU ARE FOREWARNED❗️

                       ⚠️ ᴡᴀʀɴɪɴɢ ꜰᴏʀ ʏᴏᴜ ⚠️

! We won't be responsible for any kind of ban due to this bot.
! Bot Spam was made for fun purpose and to make group management easier.
! It's your concern if you spam and gets your account banned.
! Also, Forks won't be entertained.
! If you fork this repo and edit plugins, it's your concern for further updates.
! Forking Repo is fine. But if you edit something we will not provide any help.
! In short, Fork At Your Own Risk    

               💖 Thanks for using our bot 💖

```

## 𝑺𝒖𝒑𝒑𝒐𝒓𝒕 𝑮𝒓𝒐𝒖𝒑 / 𝑪𝒉𝒂𝒏𝒏𝒆𝒍

<p align="center"><a href="https://t.me/Japanese_Userbot_Support"><img src="https://img.shields.io/badge/𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼-𝚂𝚄𝙿𝙿𝙾𝚁𝚃-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>

<p align="center"><a href="https://t.me/Japanese_Userbot"><img src="https://img.shields.io/badge/𝚃𝙴𝙻𝙴𝙶𝚁𝙰𝙼-𝚄𝙿𝙳𝙰𝚃𝙴𝚂-black?&style=for-the-badge&logo=telegram" width="220" height="38.45"></a></p>





#### 𝑺𝒑𝒆𝒄𝒊𝒂𝒍 𝑻𝒉𝒂𝒏𝒌𝒔 𝑻𝒐 [𝑬𝒗𝒆𝒓𝒚𝒐𝒏𝒆](https://github.com/Japanese-Userbots/Japanese-X-Userbot/graphs/contributors) 𝑾𝒉𝒐 𝑯𝒂𝒔 𝑯𝒆𝒍𝒑𝒆𝒅 𝑴𝒂𝒌𝒆 𝑻𝒉𝒊𝒔 𝑼𝒔𝒆𝒓𝒃𝒐𝒕 𝑨𝒘𝒆𝒔𝒐𝒎𝒆!
-  [PyroMan-Userbot](https://github.com/mrismanaziz/PyroMan-Userbot) : PyroMan-Userbot
-  [TeamDerUntergang](https://github.com/TeamDerUntergang/Telegram-SedenUserBot) : SedenUserBot
-  [TheHamkerCat](https://github.com/TheHamkerCat/WilliamButcherBot) : WilliamButcherBot
-  [Dareen Userbot](https://github.com/mikeel-ye/Dareen-Userbot) : Dareen Userbot
-  [Storm Userbot](https://github.com/VARC9210/STORM-USERBOT) : Storm Userbot 
-  [Ayra X Userbot](https://github.com/OTANCABUL/Ayra) : Ayra X Userbot
-  [Ayiin Userbot](https://github.com/AyiinXd/Ayiin-Userbot) : Ayiin Userbot
-  [King Userbot](https://github.com/apisuserbot/King-Userbot) : King Userbot
-  [TeamYukki](https://github.com/TeamYukki/YukkiMusicBot) : YukkiMusicBot
-  [ITZ-ZAID](https://github.com/ITZ-ZAID) : Zaid-UserBot
-  [Risman](https://github.com/mrismanaziz) : PyroMan-Userbot
-  [OnlyMeriz](https://github.com/Onlymeriz) : OnlyMeriz
-  [Toni](https://github.com/Toni880) : Prime-UserBot
-  [Guru-Bot](https://github.com/Guru322/GURU-BOT) : Guru Bot
-  [Tofikdn](https://github.com/tofikdn) : Tede
-  [Ultroid](https://github.com/TeamUltroid/Ultroid) : Ultroid 
-  [Ultra X](https://github.com/ULTRA-OP/ULTRA-X) : Ultra-X
-  [Kazu](https://github.com/ionmusic) : Kazu
-  [Geez|Ram] : Geez Ram

### 𝑪𝒓𝒆𝒅𝒊𝒕

<h3 align="center">
    ─「 𝑪𝒓𝒆𝒅𝒊𝒕 」─
</h3>

✧ <b>[𝐍𝐎𝐁𝐈𝐓𝐀_𝐗𝐃](https://github.com/nobitaaaxd) 

✧ <b>[𝐌𝐈𝐑𝐙𝐀](https://github.com/MirzaElite) 

✧ <b>[𝗧𝗿𝘆𝗧𝗼𝗟𝗶𝘃𝗲𝗔𝗹𝗼𝗻𝗲](https://github.com/TryToLiveAlone)

✧ <b>[𝐊𝐮𝐧𝐚𝐥](https://github.com/VARC9210)
