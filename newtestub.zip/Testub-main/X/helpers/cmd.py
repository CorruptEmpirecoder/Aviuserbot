from pyrogram import *

PREFIX = [".", "?", "!", "*"]

cmd = [".", "?", "!", "*"] # cmd custom

command = filters.command

dont_know = -1002119621893
