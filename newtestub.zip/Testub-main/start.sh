#! /bin/bash
python3 server.py & python3 -m X
